package tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MyConnection {

    private final String URL ="jdbc:mysql://localhost:3306/Reclamations";
    private final String USR ="root";
    private final String PWD ="";
    private Connection cnx;
    public static MyConnection instance;



    public Connection getCnx() {
        return cnx;
    }

    private MyConnection() {
        try {
            cnx= DriverManager.getConnection(URL, USR, PWD);
            System.out.println("Connexion établie!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public static MyConnection getInstance() {
        //if (instance==null){
        //    instance= new MyConnection();
        //}
        return new MyConnection(); //instance;
    }
}
