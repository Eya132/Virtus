package Mytest;
/*
import entities.Support;
import services.SupportServices;
*/
public class MyTest2 {
    /*public static void main(String[] args) {
        Support s = new Support("hello",55584439,"informatique","photo");
        SupportServices ss =  new SupportServices();
         ss.addEntity(s);
        // System.out.println("before editing");
        System.out.println(ss.getAllData());
       // s.setId_s(6);
       //  ss.DeleteEntity(s);
         //ss.updateEntity(s);
      //  System.out.println("after editing");
       // System.out.println(ss.getAllData());
    }*/
}
