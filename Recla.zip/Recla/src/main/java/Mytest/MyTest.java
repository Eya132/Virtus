package Mytest;
/*
import entities.Reclamation;
import services.ReclamationServices;
//import java.sql.Date;
import java.util.Date;
*/

public class MyTest {
  /*  public static void main(String[] args) {
        // Obtenir la date actuelle
        Date dateUtil = new Date();

        // Convertir java.util.Date en java.sql.Date
        java.sql.Date dateSql = new java.sql.Date(dateUtil.getTime());

        Reclamation r = new Reclamation("hello", dateSql, "question", 8);
        ReclamationServices rs = new ReclamationServices();
        rs.addEntity(r);
        //System.out.println("before editing");
        //System.out.println(rs.getAllData());
       //  r.setId(12);
        // ps.DeleteEntity(p);
       // rs.updateEntity(r);
       // System.out.println("after editing");
        System.out.println(rs.getAllData());

    }
    */

}
