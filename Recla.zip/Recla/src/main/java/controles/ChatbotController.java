package controles;

import entities.ChatBot;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ChatbotController {

    private ChatBot chatbot;

    @FXML
    private TextField userInputField;

    @FXML
    private TextArea chatArea;

    @FXML
    private Button sendButton;

    @FXML
    private void initialize() {
        chatbot = new ChatBot();
    }

    @FXML
    private void handleSendButton(ActionEvent event) {
        String userMessage = userInputField.getText();
        String botResponse = chatbot.getResponse(userMessage);

        // Afficher l'entrée de l'utilisateur et la réponse du bot dans la zone de chat
        chatArea.appendText("User: " + userMessage + "\n");
        chatArea.appendText("Bot: " + botResponse + "\n");

        // Effacer le champ de saisie de l'utilisateur
        userInputField.clear();
    }
}