package controles;
import entities.Reclamation;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class DetailsReclamationController {

    @FXML
    private Label lblContenu;

    @FXML
    private Label lblCategorie;

    @FXML
    private Label lblSupport;

    // Méthode pour initialiser les détails de la réclamation
    public void setReclamation(Reclamation reclamation) {
        lblContenu.setText(reclamation.getContenu());
        lblCategorie.setText(reclamation.getCategorie());
        lblSupport.setText(Integer.toString(reclamation.getId_s()));
    }
}
