package controles;
import entities.Support;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.embed.swing.SwingFXUtils;
import org.controlsfx.control.Notifications;
import toolkit.QRCodeGenerator;
import entities.Reclamation;
import javafx.stage.Stage;
import services.ReclamationServices;
import services.SupportServices;

import java.io.IOException;
import java.sql.SQLException;


public class listereclam {

    @FXML
    private ChoiceBox<String> support;

    @FXML
    private TextArea contenu;

    @FXML
    private ComboBox<String> categorie;

    @FXML
    private Label contenuerror;


    @FXML
    void initialize() {
        SupportServices suppportServices = new SupportServices();

        ObservableList<String> supportsList = FXCollections.observableList(suppportServices.getAllResponsableNames());
        support.setItems(supportsList);

        categorie.getItems().addAll("proposition","question");


        //contenuerror.textProperty().addListener((observable, oldValue, newValue) -> isValidcontenu(newValue));

    }

    private void displayErrorAlert(String contenu, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(contenu);
        alert.setContentText(content);
        alert.show();
    }

    private ReclamationServices rs = new ReclamationServices();
    private SupportServices ss=new SupportServices();

    @FXML
    void ajouterReclamationAction(ActionEvent event) {
        String contenue = contenu.getText();
        String categories = categorie.getValue();
        String support1 = support.getValue();

        if (contenue.isEmpty() || categories.isEmpty() || support1 == null ) {
            // Affichez une alerte si un champ est manquant
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Champs manquants");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez remplir tous les champs.");
            alert.showAndWait();
            return;
        }
        // Créer un objet Reclamation avec les valeurs récupérées
        int support2 = ss.getCategoryIDByName(support1);

        Reclamation reclamation = new Reclamation(contenue,categories,support2);

        // Utilisez votre service pour ajouter le Reclamation à la base de données
        rs.addEntity(reclamation);

        // Affichez un message de réussite
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Succès");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Le Reclamation a été ajouté avec succès.");
        successAlert.showAndWait();

        // Effacez les champs de saisie
        clearFields();
       
    }
    private void clearFields() {
        contenu.clear();

    }


    @FXML
    void afficher(ActionEvent event) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Afficher.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void Ajouter(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterSup.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            Notifications.create().title("Done").text("Le support a été ajoutée").showConfirm();
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void affichersup(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/affichsupp.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}