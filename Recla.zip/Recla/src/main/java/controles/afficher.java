package controles;
import entities.PDFExporter;
import entities.Reclamation;
import entities.Support;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import services.ReclamationServices;
import javafx.embed.swing.SwingFXUtils;
import toolkit.QRCodeGenerator;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Optional;

public class afficher {
    @FXML
    private TableColumn<Reclamation, String> contenu;

    @FXML
    private TableColumn<Reclamation, String> cat;

    @FXML
    private TableColumn<Reclamation, String> support;

    @FXML
    private TableColumn<Reclamation, Void> cat_actions; // Corrected TableColumn type

    @FXML
    private TableView<Reclamation> list_reclamation;
    @FXML
    private ImageView qrCodeImageView;

    private ReclamationServices rs = new ReclamationServices();
    @FXML
    void initialize() {

        ObservableList<Reclamation> reclamations = FXCollections.observableList(rs.getAllData());

        contenu.setCellValueFactory(new PropertyValueFactory<>("contenu"));
        cat.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        support.setCellValueFactory(new PropertyValueFactory<>("support"));


        // Set the cell factory for the actions column
        cat_actions.setCellFactory(createActionsCellFactory());

        list_reclamation.setItems(reclamations);
        list_reclamation.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) { // Détecte un double clic
                Reclamation reclamation = list_reclamation.getSelectionModel().getSelectedItem();
                if (reclamation != null) {
                    afficherDetailsReclamation(reclamation);
                }
            }
        });

    }
    private Callback<TableColumn<Reclamation, Void>, TableCell<Reclamation, Void>> createActionsCellFactory() {
        return new Callback<TableColumn<Reclamation, Void>, TableCell<Reclamation, Void>>() {
            @Override
            public TableCell<Reclamation, Void> call(final TableColumn<Reclamation, Void> param) {
                return new TableCell<Reclamation, Void>() {
                    private void handle(ActionEvent event) {
                        Reclamation reclamation = getTableView().getItems().get(getIndex());
                        try {
                            FXMLLoader loader = new FXMLLoader(getClass().getResource("/UpdateReclam.fxml"));
                            Parent root = loader.<Parent>load();

                            UpdateReclam updateController = loader.getController();
                            updateController.setReclamation(reclamation);

                            Stage updateStage = new Stage();
                            updateStage.setTitle("Update Reclamation");
                            updateStage.setScene(new Scene(root));
                            updateStage.showAndWait();

                            refreshList();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }

                    private final Button btnUpdate = new Button("Update");
                    private final Button btnDelete = new Button("Delete");

                    {
                        // Action for the update button
                        btnUpdate.setOnAction(this::handle);
                        btnDelete.setOnAction(event ->handleDelete() );
                    }

                    // This method is called whenever the cell needs to be updated
                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {

                            // Set the buttons in the cell
                            HBox buttons = new HBox(btnUpdate, btnDelete);
                            setGraphic(buttons);
                        }
                    }
                };
            }
        };
    }
    private void afficherDetailsReclamation(Reclamation reclamation) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/DetailsReclamation.fxml"));
            Parent root = loader.load();

            DetailsReclamationController detailsController = loader.getController();
            detailsController.setReclamation(reclamation);

            Stage detailsStage = new Stage();
            detailsStage.setTitle("Détails de la Réclamation");
            detailsStage.setScene(new Scene(root));
            detailsStage.showAndWait();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void refreshList() {
        ObservableList<Reclamation> updatedList = FXCollections.observableList(rs.getAllData());
        list_reclamation.setItems(updatedList);
    }
    @FXML
    void handleUpdate() {
        Reclamation selectedProjet = list_reclamation.getSelectionModel().getSelectedItem();
        if (selectedProjet != null) {
            // Load the update scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/UpdateReclam.fxml"));
            Parent updateScene;
            try {
                updateScene = loader.load();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }

            // Get the controller for the update scene
            UpdateReclam updateController = loader.getController();
            updateController.setReclamation(selectedProjet);

            // Create a new stage for the update scene
            Stage updateStage = new Stage();
            updateStage.setTitle("Update Reclamation");
            updateStage.setScene(new Scene(updateScene));

            // Show the update stage
            updateStage.showAndWait();

            // After the update scene is closed, refresh the table view
            refreshList();
        } else {
            // No item selected, show an information alert
            showAlert(Alert.AlertType.INFORMATION, "Information", null, "Veuillez sélectionner un projet à mettre à jour.");
        }
    }
    void handleDelete() {
        Reclamation selectedProjet = list_reclamation.getSelectionModel().getSelectedItem();
        if (selectedProjet != null) {
            // Show confirmation dialog
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Confirmation de suppression");
            alert.setContentText("Voulez-vous vraiment supprimer cette reclamation ?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // User confirmed, delete the selected item
                rs.DeleteEntityWithConfirmation(selectedProjet);
                refreshList(); // Refresh the TableView
            }
        } else {
            // No item selected, show an information alert
            showAlert(Alert.AlertType.INFORMATION, "Information", null, "Veuillez sélectionner un projet à supprimer.");
        }
    }
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    @FXML
    void ajouter(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Ajouter.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void rowClickkk(javafx.scene.input.MouseEvent mouseEvent) {

        if (mouseEvent.getClickCount() == 1) {
            Reclamation selection = list_reclamation.getSelectionModel().getSelectedItem();

            if (selection != null) {
                //    idlabel.setText(String.valueOf(selection.getId()));


                String userData =
                        "id reclamation : " + selection.getId_r() +"\n" +
                                "nom support :  " + selection.getNomSupport() + "\n" +
                                "contenue : " + selection.getContenu() + "\n" +
                                "categorie : " + selection.getCategorie()  ;


                BufferedImage qrCodeImage = QRCodeGenerator.generateQRCode(userData, 200, 200);

                // Afficher le QR code où vous le souhaitez, peut-être dans un ImageView
                if (qrCodeImage != null) {
                    Image fxImage = SwingFXUtils.toFXImage(qrCodeImage, null);
                    qrCodeImageView.setImage(fxImage);
                }
            }
        }
    }
    public void print(ActionEvent actionEvent) {
        ObservableList<Reclamation> data = list_reclamation.getItems();
        PDFExporter.exportToPDF(data);
    }

    public void rowClick(MouseEvent mouseEvent) {
    }
}
