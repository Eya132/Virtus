package controles;
import entities.Support;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import services.SupportServices;

import java.io.IOException;

import static java.lang.Integer.valueOf;

public class listsupp {

    @FXML
    private TextField nomTextField;
    @FXML
    private TextField TelTextField;

    @FXML
    private TextField DomaineTextField;

    @FXML
    void ajouter(ActionEvent event) {
        String nom = nomTextField.getText();
        Integer tel = valueOf(TelTextField.getText());
        String domaine = DomaineTextField.getText();

        Support c = new Support(nom, tel, domaine);
        SupportServices ps = new SupportServices();
        try {
            ps.addEntity(c);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("le support a été ajouté avec succes");
            alert.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText(e.getMessage());
            alert.show();
        }
    }

    @FXML
    void affichersupp(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AffichSupp.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void afficherrecl(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Afficher.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
