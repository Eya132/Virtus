package controles;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class EmailController {

    // Adresse e-mail de l'expéditeur
    private static final String FROM_EMAIL = "mohamedamine.abdellaoui@esprit.tn"; // Remplacez par votre adresse e-mail
    private static final String PASSWORD = "vxmq bvuu rfch ifvv"; // Remplacez par votre mot de passe
    @FXML
    private TextField toField;

    @FXML
    private TextField ccField;

    @FXML
    private TextField bccField;

    @FXML
    private TextField subjectField;



    @FXML
    private TextArea messageArea;

    @FXML
    private Button sendButton;

    @FXML
    void handleSendButton() {
        String to = toField.getText().trim();
        String cc = ccField.getText().trim();
        String bcc = bccField.getText().trim();
        String subject = subjectField.getText().trim();
        String message = messageArea.getText().trim();

        // Configuration de la session
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com"); // Remplacez par votre serveur SMTP
        properties.put("mail.smtp.port", "587"); // Port SMTP

        // Authentification
        Authenticator authenticator = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, PASSWORD);
            }
        };

        // Création de la session
        Session session = Session.getInstance(properties, authenticator);

        try {
            // Création du message
            Message emailMessage = new MimeMessage(session);
            emailMessage.setFrom(new InternetAddress(FROM_EMAIL));
            emailMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            if (!cc.isEmpty()) {
                emailMessage.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
            }
            if (!bcc.isEmpty()) {
                emailMessage.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bcc));
            }
            emailMessage.setSubject(subject);
            emailMessage.setText(message);

            // Envoi du message
            Transport.send(emailMessage);

            System.out.println("E-mail envoyé avec succès !");
        } catch (MessagingException e) {
            System.out.println("Erreur lors de l'envoi de l'e-mail : " + e.getMessage());
        }
    }
}
