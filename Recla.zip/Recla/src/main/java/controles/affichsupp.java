package controles;
import entities.Support;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import services.SupportServices;

import java.io.IOException;

public class affichsupp {
    @FXML
    private TableColumn<Support, String> nomSupp;

    @FXML
    private TableColumn<Support, Integer> numSupp;

    @FXML
    private TableColumn<Support, String> DomSupp;

    @FXML
    private TableColumn<Support, Void> cat_actions; // Corrected TableColumn type

    @FXML
    private TableView<Support> list_support;

    private SupportServices supportServices = new SupportServices();
    @FXML
    void Retour(ActionEvent event) {
        // Handle the action to go back or close the current view
    }
    @FXML
    void initialize() {

        ObservableList<Support> supports = FXCollections.observableList(supportServices.getAllSupport());

        nomSupp.setCellValueFactory(new PropertyValueFactory<>("Nom_responsable"));
        numSupp.setCellValueFactory(new PropertyValueFactory<>("num_tel"));
        DomSupp.setCellValueFactory(new PropertyValueFactory<>("domaine"));

        // Set the cell factory for the actions column
        cat_actions.setCellFactory(createActionsCellFactory());

        list_support.setItems(supports);

    }
    public void refreshList() {
        ObservableList<Support> updatedList = FXCollections.observableList(supportServices.getAllData());
        list_support.setItems(updatedList);
    }
    private Callback<TableColumn<Support, Void>, TableCell<Support, Void>> createActionsCellFactory() {
        return new Callback<TableColumn<Support, Void>, TableCell<Support, Void>>() {
            @Override
            public TableCell<Support, Void> call(final TableColumn<Support, Void> param) {
                return new TableCell<Support, Void>() {
                    private final Button btnUpdate = new Button("Update");
                    private final Button btnDelete = new Button("Delete");

                    {
                        btnUpdate.setOnAction(event -> {
                            Support support = getTableView().getItems().get(getIndex());
                            try {
                                FXMLLoader loader = new FXMLLoader(getClass().getResource("/UpdateSupport.fxml"));
                                Parent root = loader.load();

                                UpdateSupport updateController = loader.getController();
                                updateController.setSupport(support);

                                Stage updateStage = new Stage();
                                updateStage.setTitle("Update Categorie");
                                updateStage.setScene(new Scene(root));
                                updateStage.showAndWait();

                                refreshList();
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        });

                        btnDelete.setOnAction(event -> {
                            Support categorie = getTableView().getItems().get(getIndex());
                            supportServices.DeleteEntity(categorie);
                            refreshList();
                        });
                    }

                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            HBox buttonsBox = new HBox(btnUpdate, btnDelete);
                            setGraphic(buttonsBox);
                        }
                    }
                };
            }
        };
    }
    @FXML
    void ajouter(ActionEvent event) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterSup.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
