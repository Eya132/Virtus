package controles;
import entities.Reclamation;
import entities.Support;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.controlsfx.control.Notifications;
import services.ReclamationServices;

import java.io.IOException;

public class UpdateReclam {
    @FXML
    private TextArea contenu;

    @FXML
    private ComboBox cat;

    @FXML
    private ChoiceBox<String> support;
    private Reclamation reclamation=new Reclamation();
    private ReclamationServices rs = new ReclamationServices();
    private affichsupp affichsuppcontroles;

    public UpdateReclam(ChoiceBox<String> support) {
        this.support = support;
    }

    void initialize() {
        // Vous pouvez charger dynamiquement les catégories à partir du service ou d'une autre source
        ObservableList<String> categories = FXCollections.observableArrayList();
        support.setItems(categories);
    }

    @FXML
    void modifier(ActionEvent event) {
        // Récupérer les nouvelles valeurs du nom, de la description et de l'identifiant du plat depuis les champs de texte
        String cotenues = contenu.getText();
        String supports = support.getValue();
        String categories = (String)cat.getValue();


        // Mettre à jour l'objet Allergie avec les nouvelles valeurs
        reclamation.setContenu(cotenues);
        reclamation.setCategorie(String.valueOf(categories));
        reclamation.setSupport(new Support(supports));





        //hotel.setHotel(new Plat(idPlat)); // Assurez-vous que la classe Plat possède un constructeur prenant l'identifiant du plat

        // Mettre à jour l'allergie dans la base de données
        ReclamationServices ReclamationServices = new ReclamationServices();
        ReclamationServices.updateEntity(reclamation);

        // Afficher une confirmation
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("L'hotel a été modifiée avec succès");
        Notifications.create().title("Done").text("La hotel a été modifer").showConfirm();
        alert.show();
    }
    private void redirectToCategorieList(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Afficher.fxml"));
            Parent root = loader.load();

            affichsupp affichsuppcontroles = loader.getController();
            affichsuppcontroles.refreshList();

            Scene scene = new Scene(root);
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
        private void showAlert(String content) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.setContentText(content);
            alert.showAndWait();
        }
    private void redirectToProjetList(ActionEvent event) {
        try {
            // Charger le fichier FXML de la liste des projets
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Afficher.fxml"));
            Parent root = loader.load();

            // Accéder au contrôleur ListProjet
            afficher affichercontroles = loader.getController();

            // Rafraîchir la liste des projets
            affichercontroles.refreshList();

            // Créer une nouvelle scène
            Scene scene = new Scene(root);

            // Récupérer la scène actuelle à partir de n'importe quel composant de la scène actuelle
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Changer la scène du stage actuel
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void setReclamation(Reclamation reclamation) {
        this.reclamation = reclamation;

        // Initialisez les champs avec les valeurs du projet
        contenu.setText(reclamation.getContenu());


        // Assurez-vous que getNomCategorie() renvoie le nom de la catégorie sous forme de String
        cat.setValue(reclamation.getCategorie());
        support.setValue(reclamation.getSupport().getNom_responsable());

    }
    @FXML
    void annuler(ActionEvent event) {
        try {
            // Load the FXML file for the "AjouterCategorie" page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Afficher.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
