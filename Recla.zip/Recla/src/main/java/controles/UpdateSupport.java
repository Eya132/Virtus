package controles;
import entities.Support;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import services.SupportServices;


import java.io.IOException;
public class UpdateSupport {

    @FXML
    private TextField nom;

    @FXML
    private TextField tel;

    @FXML
    private TextField dom;

    private Support support;

    private SupportServices supportServices = new SupportServices();
    private affichsupp affichsuppcontroles;
    @FXML
    void modifier(ActionEvent event) {
        String nouveaunom = nom.getText();
        Integer nouveautel = Integer.valueOf(tel.getText());
        String nouveaudom = dom.getText();


        if (support != null) {
            support.setNom_responsable(nouveaunom);
            support.setNum_tel(nouveautel);
            support.setDomaine(nouveaudom);

            try {
                supportServices.updateEntity(support);
                showAlert("Le support a été modifiée avec succès.");
                redirectToCategorieList(event);
            } catch (Exception e) {
                e.printStackTrace();
                showAlert("Erreur lors de la modification du support.");
            }
        } else {
            showAlert("Veuillez sélectionner un support à mettre à jour.");
        }
    }
    private void redirectToCategorieList(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/affichsupp.fxml"));
            Parent root = loader.load();

            affichsupp affichsuppcontroles = loader.getController();
            affichsuppcontroles.refreshList();

            Scene scene = new Scene(root);
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void setSupport(Support support) {
        this.support = support;
        nom.setText(support.getNom_responsable());

        tel.setText(String.valueOf(support.getNum_tel()));
        dom.setText(support.getDomaine());

    }

    public void setListCategorieController(affichsupp affichsuppcontroles) {
        this.affichsuppcontroles = affichsuppcontroles;
    }
    private void showAlert(String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    @FXML
    void annuler(ActionEvent event) {
        try {
            // Load the FXML file for the "AjouterSupport" page
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/affichsupp.fxml"));
            Parent root = loader.load();

            // Create a new scene
            Scene scene = new Scene(root);

            // Get the current stage
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Set the new scene on the current stage
            currentStage.setScene(scene);
            currentStage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
