package entities;

import javafx.scene.control.ComboBox;

import java.util.Date;

public class Reclamation extends Support {
    private int id_r;
    private String contenu ;

    private String categorie ;
    private Support support ;

    public Reclamation() {
    }

    public Reclamation(String contenu,  String categorie) {
        this.contenu = contenu;

        this.categorie = categorie;
        this.support = support;
    }
    public Reclamation(String contenu,  String categorie, Support support) {
        this.contenu = contenu;

        this.categorie = categorie;
        this.support = support;

    }


    public Reclamation(int id_r, String contenu,  String categorie, Support support) {
        this.id_r = id_r;
        this.contenu = contenu;

        this.categorie = categorie;
        this.support = support;
    }

    public Reclamation(String contenue, String categories, int support2) {
        this.contenu= contenue;
        this.categorie=categories;
        this.support=new Support();
        this.support.setId_s(support2);
    }


    public int getId_r() {
        return id_r;
    }

    public void setId_r(int id_r) {
        this.id_r = id_r;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }


    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public Support getSupport() {
        return support;
    }

    public void setSupport(Support support) {
        this.support = support;
    }

    public int getIdSupport() {
        if (support != null) {
            return support.getId_s();
        } else {
            return -1; // ou une valeur qui indique l'absence de catégorie, selon vos besoins
        }
    }

    public String getNomSupport() {
        if (support != null) {
            return support.getNom_responsable();
        } else {
            return null;
        }
    }

    @Override
    public java.lang.String toString() {
        return "Reclamation{" +
                "id_r=" + id_r +
                ", contenu=" + contenu +

                ", categorie=" + categorie +
                ", support=" + support +
                '}';
    }
}
