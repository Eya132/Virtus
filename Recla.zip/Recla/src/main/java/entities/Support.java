package entities;

public class Support {
    private int id_s ;
    private  String nom_responsable ;
    private int num_tel ;
    private  String domaine ;
    private  String image ;

    public Support() {
    }

    public Support(String nom_responsable, int num_tel, String domaine) {
        this.nom_responsable = nom_responsable;
        this.num_tel = num_tel;
        this.domaine = domaine;

    }

    public Support(int id_s, String nom_responsable, int num_tel, String domaine) {
        this.id_s = id_s;
        this.nom_responsable = nom_responsable;
        this.num_tel = num_tel;
        this.domaine = domaine;

    }

    public Support(String support) {
    }


    public int getId_s() {
        return id_s;
    }

    public void setId_s(int id_s) {
        this.id_s = id_s;
    }

    public String getNom_responsable() {
        return nom_responsable;
    }

    public void setNom_responsable(String nom_responsable) {
        this.nom_responsable = nom_responsable;
    }

    public Integer getNum_tel() {
        return num_tel;
    }

    public void setNum_tel(int num_tel) {
        this.num_tel = num_tel;
    }

    public String getDomaine() {
        return domaine;
    }

    public void setDomaine(String domaine) {
        this.domaine = domaine;
    }



    @Override
    public String toString() {
        return "Support{" +
                "id_s=" + id_s +
                ", nom_responsable='" + nom_responsable + '\'' +
                ", num_tel=" + num_tel +
                ", domaine='" + domaine + '\'' +

                '}';
    }
}
