package entities ;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ChatBot {

    private Map<String, String> responses;
    private String[] prohibitedWords = {"fuck you", "zah", "bara zamer"};
    private Map<String, String> userMemory;

    public ChatBot() {
        // Define simple rule-based responses
        responses = new HashMap<>();
        responses.put("hello", "Hi there! How can I help you?");
        responses.put("goodbye", "Goodbye! Have a great day.");
        userMemory = new HashMap<>();
    }

    public String getResponse(String userMessage) {
        if (containsProhibitedWord(userMessage)) {
            return "I'm sorry, but I cannot respond to inappropriate language.";
        }

        if (userMessage.toLowerCase().contains("time")) {
            return getCurrentTime();
        }
        if (userMessage.toLowerCase().contains("date")) {
            return getCurrentDate();
        }
        if (userMessage.toLowerCase().contains("weather")) {
            return "The weather is sunny and warm.";
        }

        // Check for other keywords
        for (String keyword : responses.keySet()) {
            if (userMessage.toLowerCase().contains(keyword)) {
                return responses.get(keyword);
            }
        }

        // If no specific keyword matched, generate a generic response
        return generateRandomResponse();
    }

    private boolean containsProhibitedWord(String userMessage) {
        for (String prohibitedWord : prohibitedWords) {
            if (userMessage.toLowerCase().contains(prohibitedWord)) {
                return true;
            }
        }
        return false;
    }

    private String getCurrentTime() {
        // Get the current time
        LocalTime currentTime = LocalTime.now();

        // Format the time using DateTimeFormatter
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
        String formattedTime = currentTime.format(formatter);

        return "The current time is: " + formattedTime;
    }

    private String getCurrentDate() {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Format the date using DateTimeFormatter
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = currentDate.format(formatter);

        return "The current date is: " + formattedDate;
    }

    private String generateRandomResponse() {
        String[] randomResponses = {
                "I'm not sure what you mean. Can you provide more details?",
                "That's interesting! Tell me more.",
                "I'm here to assist you. What else can I do for you?",
                "Let's change the topic. What are your hobbies?"
        };

        Random random = new Random();
        int index = random.nextInt(randomResponses.length);
        return randomResponses[index];
    }
}
