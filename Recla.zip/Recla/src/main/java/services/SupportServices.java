package services;

import entities.Support;
import tools.MyConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SupportServices implements IService<Support> {
    @Override
    public void addEntity(Support support) {
        String requete = "INSERT INTO support (nom_responsable,num_tel,domaine) VALUES (?,?,?)";
        try {
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setString(1, support.getNom_responsable());
            pst.setInt(2,support.getNum_tel());
            pst.setString(3, support.getDomaine());

            pst.executeUpdate();
            System.out.println("Support Added");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void updateEntity(Support support) {
        String requete = "UPDATE support SET nom_responsable=?, num_tel=? , domaine=?  WHERE id_s=?";
        try {
            System.out.println("Executing update query: " + requete);

            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setString(1, support.getNom_responsable());
            pst.setInt(2,support.getNum_tel());
            pst.setString(3, support.getDomaine());

            //  pst.setInt(3, projet.getUser_id()); // Assuming you have a getUser_id method in your Projet class
            pst.setInt(4, support.getId_s());
/*
            System.out.println("Updating project with ID " + projet.getId() + ":");
            System.out.println("Title: " + projet.getTitre());
            System.out.println("Description: " + projet.getDescription());
            System.out.println("User ID: " + projet.getUser_id());
*/
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Support Updated");
            } else {
                System.out.println("Support not found or not updated");
            }
        } catch (SQLException e) {
            System.out.println("Error during update: " + e.getMessage());
        }
    }

    @Override
    public void DeleteEntity(Support support) {
        String requete = "DELETE FROM support WHERE id_s=?";
        try {
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setInt(1, support.getId_s());

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Support Deleted");
            } else {
                System.out.println("Support not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    @Override
    public List<Support> getAllData() {
        List<Support> data = new ArrayList<>();
        String requete = "SELECT * FROM support";
        try {
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                    Support s = new Support();
                s.setId_s(rs.getInt(1));
                s.setNom_responsable(rs.getString("Nom_responsable"));
                s.setNum_tel(rs.getInt("Num_tel"));
                s.setDomaine(rs.getString("Domaine"));






                data.add(s);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return data;
    }
    public int getCategoryIDByName(String nom_responsable) {
        int supportId = -1; // Default value or any other value indicating the absence of category

        String query = "SELECT id_s FROM support WHERE nom_responsable = ?";

        try (Connection connection = MyConnection.getInstance().getCnx();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, nom_responsable);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    supportId = resultSet.getInt("id_s");
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return supportId;
    }
    public Support getSupportByResponsable(String nom_responsable) {
        Support support = null;

        String query = "SELECT * FROM support WHERE nom_responsable = ?";

        try (Connection connection = MyConnection.getInstance().getCnx();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, nom_responsable);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    support = new Support();
                    support.setId_s(resultSet.getInt("id_s"));
                    support.setNom_responsable(resultSet.getString("nom_responsable"));
                    support.setNum_tel(resultSet.getInt("num_tel"));
                    support.setDomaine(resultSet.getString("domaine"));
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return support;
    }


    public Support getSupportById(int id_s) {
        Support sup = null;
        String requete = "SELECT * FROM support WHERE id_s = ?";

        try {
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setInt(1, id_s);

            // Execute the query and get the result set
            ResultSet rs = pst.executeQuery();

            // Check if there is a result
            if (rs.next()) {
                // Create a new Categorie instance and populate it with data from the result set
                sup = new Support();
                sup.setId_s(rs.getInt("id_s"));
                sup.setNom_responsable(rs.getString("nom_responsable"));
                sup.setNum_tel(rs.getInt("Num_tel"));
                sup.setDomaine(rs.getString("Domaine"));

                // Add other attributes as needed
            }

            // Close the result set and statement
            //rs.close();
            //pst.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return sup;
    }
    public List<Support> getAllSupport() {
        List<Support> support = new ArrayList<>();
        String requete = "SELECT * FROM support";

        try {
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            ResultSet rs = st.executeQuery(requete);

            while (rs.next()) {
                Support c = new Support();
                c.setId_s(rs.getInt(1));
                c.setNom_responsable(rs.getString("nom_responsable"));
                c.setNum_tel(rs.getInt("num_tel"));
                c.setDomaine(rs.getString("domaine"));

                support.add(c);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return support;
    }
    public List<String> getAllResponsableNames() {
        List<String> nomResponsables = new ArrayList<>();
        String requete = "SELECT nom_responsable FROM support"; // Modification de la requête pour ne sélectionner que le nom_responsable

        try {
            Statement st = MyConnection.getInstance().getCnx().createStatement();
            ResultSet rs = st.executeQuery(requete);

            while (rs.next()) {
                String nomResponsable = rs.getString("nom_responsable");
                nomResponsables.add(nomResponsable);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return nomResponsables;
    }

}