package services;

import entities.Reclamation;
import entities.Support;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import tools.MyConnection;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ReclamationServices implements IService<Reclamation> {

    Connection connection = MyConnection.getInstance().getCnx();

    @Override
    public void addEntity(Reclamation reclamation) {
        String requete ="INSERT INTO reclamation (contenu,categorie,id_s) VALUES (?,?,?)";
        try {

            PreparedStatement pst =  connection.prepareStatement(requete);
            pst.setString(1, reclamation.getContenu());
            pst.setString(2, reclamation.getCategorie());
            pst.setInt(3, reclamation.getIdSupport());
            pst.executeUpdate();
            System.out.println("Reclamations Added");

        } catch (SQLException e) {
            System.out.println("Insert : " + e.getMessage());
        }
    }

    @Override
    public void updateEntity(Reclamation reclamation) {
        String requete = "UPDATE reclamation SET contenu=?, categorie=?, id_s=? WHERE id_r=?";

        try {
            System.out.println("Executing update query: " + requete);

            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setString(1, reclamation.getContenu());

            pst.setString(2, reclamation.getCategorie());
           pst.setInt(3, reclamation.getId_s());

            //  pst.setInt(3, projet.getUser_id()); // Assuming you have a getUser_id method in your Projet class
            pst.setInt(4, reclamation.getId_r());
/*
            System.out.println("Updating project with ID " + projet.getId() + ":");
            System.out.println("Title: " + projet.getTitre());
            System.out.println("Description: " + projet.getDescription());
            System.out.println("User ID: " + projet.getUser_id());
*/
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Reclamations Updated");
            } else {
                System.out.println("Reclamations not found or not updated");
            }
        } catch (SQLException e) {
            System.out.println("Error during update: " + e.getMessage());
        }
    }

@Override
    public void DeleteEntity(Reclamation reclamation) {
        String requete = "DELETE FROM reclamation WHERE id_r=?";
        try {
            PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(requete);
            pst.setInt(1, reclamation.getId_r());

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Reclamations Deleted");
            } else {
                System.out.println("Reclamations not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    @Override
    public List<Reclamation> getAllData() {
        List<Reclamation> data = new ArrayList<>();
        String requete = "SELECT * FROM reclamation";
        try {
            Connection connection = MyConnection.getInstance().getCnx();
            if (connection != null) { // Vérifie si la connexion est valide
                Statement st = connection.createStatement();
                ResultSet rs = st.executeQuery(requete);
                while (rs.next()) {
                    Reclamation r = new Reclamation();
                    r.setId_r(rs.getInt(1));
                    r.setContenu(rs.getString("Contenu"));
                    r.setCategorie(rs.getString("Categorie"));


                    // Vérifie si l'id_s n'est pas NULL avant de récupérer le support
                    int idSupport = rs.getInt("id_s");
                    if (!rs.wasNull() && idSupport != 0) {
                        Support sup = new Support();
                        SupportServices supserv = new SupportServices();
                        sup = supserv.getSupportById(idSupport);
                        r.setSupport(sup);
                    } else {
                        r.setSupport(null); // Mettre à NULL si id_s est NULL ou 0
                    }

                    data.add(r);
                }
            } else {
                System.out.println("La connexion à la base de données est nulle.");
            }
        } catch (SQLException e) {
            System.out.println("Erreur lors de l'exécution de la requête SQL : " + e.getMessage());
        }

        System.out.println(data.size());
        return data;
    }

    public boolean isTitreUnique(String contenu) throws SQLException {
        String query = "SELECT COUNT(*) FROM reclamation WHERE contenu = ?";

        try (PreparedStatement pst = MyConnection.getInstance().getCnx().prepareStatement(query)) {
            pst.setString(1, contenu);

            try (ResultSet rs = pst.executeQuery()) {
                rs.next();
                int count = rs.getInt(1);

                // If count is greater than 0, a project with the same title already exists
                return count == 0;
            }
        }

    }
    public void DeleteEntityWithConfirmation(Reclamation logement) {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Suppression de reclamation");
        confirmationAlert.setContentText("Voulez-vous vraiment supprimer ce reclamation?");

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // User confirmed deletion, proceed with deletion
            DeleteEntity(logement);
        }
    }
}
